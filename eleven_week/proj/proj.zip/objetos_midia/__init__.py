from objetos_midia.Filme import Filme
from objetos_midia.Serie import Serie